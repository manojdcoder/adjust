var Adjust = require("ti.adjust");
Adjust.init({
	key : "API_KEY",
	environment : Adjust.ENVIRONMENT_SANDBOX,
	logLevel : Adjust.LOG_LEVEL_VERBOSE
}); 